/**
 * The type Bank exception.
 */
public class BankException extends Exception {
  /**
   * Instantiates a new Bank exception.
   *
   * @param e the e
   */
  public BankException(String e) {
    System.out.println(e);
  }
}